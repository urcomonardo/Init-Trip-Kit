MUELLER CHANGELOG
=================

v 1.1 (4.1.2013)
^^^^^^^^^^^^^^^^

* Slightly refactored _grid_system.scss works.
* Fixed an error with overwriting the default last class.
* Added a default_class in order to overwrite the default behaviour with different media-queries.
* Improved show/hide-classes.

v 1.0 (22.6.2012)
^^^^^^^^^^^^^^^^^

* First release of MUELLER.