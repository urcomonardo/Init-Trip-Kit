Zimit Framework
=====

###Awesome, solid, responsive and complete front-end prototyping framework for web-developers

######What is Zimit?

Zimit is an open source project created by Jorge Garrido also known as FireZenk, with the intention of providing a robust and comprehensive basis for rapid prototyping of responsive web pages.


######LESS based

With unique features and functions of LEES, Zimit is a modular and scalable framework. LESS also helps make readable code and easily customizable.

######Light weight

The compiled and minified file: 83kb! Optionally you can extend the framework with the awesome set of typographic icons.

######Browser Support

Zimit Framework is tested and supported in major modern browsers like: Chrome, Firefox, Opera, Safari and Internet Explorer9+.

#####Info, docs & more
[Zimit Framework](http://firezenk.github.com/zimit/)


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/FireZenk/zimit/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

