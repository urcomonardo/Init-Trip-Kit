# Zimit Change log

v.0.9
------
- Initial release

v.0.9.5
------
- Added HTML5 audio component
- Added Zimit.js

v.0.9.8
------
- Added rating component
- Updated Ligature Symbols

v.0.9.9
------
- Added font compatibility over https
- Added icon font compatibility css
- Added Ligature Symbols OTF format
- Updated Ligature Symbols 2.11